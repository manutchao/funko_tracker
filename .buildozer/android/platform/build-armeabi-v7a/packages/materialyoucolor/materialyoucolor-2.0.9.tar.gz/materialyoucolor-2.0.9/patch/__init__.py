from .celebi import QuantizeCelebi, StbLoadImage
